
#pragma once

#include <Rcpp/Lightest>
// #include <spdlog/stopwatch.h>   		// Do not include stopwatch to avoid fmt spilling
#include <tinyspdl/stopwatch.h>
